/* Generated automatically. */
static const char configuration_arguments[] = "../../gcc-4.6.3/configure --prefix=/Users/rwessels/opt/msp430 --enable-languages=c,c++ --disable-nls --target=msp430 --program-prefix=msp430-";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
