/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-4.6.2/configure --target=msp430 --enable-languages=c,c++ --program-prefix=msp430- --prefix=/Users/rwessels/mspgcc-install";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
