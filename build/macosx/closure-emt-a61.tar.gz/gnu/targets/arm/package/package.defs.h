/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A65
 */

#ifndef gnu_targets_arm__
#define gnu_targets_arm__



#endif /* gnu_targets_arm__ */ 
