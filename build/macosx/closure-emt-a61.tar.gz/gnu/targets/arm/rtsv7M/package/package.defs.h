/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A65
 */

#ifndef gnu_targets_arm_rtsv7M__
#define gnu_targets_arm_rtsv7M__


/*
 * ======== module gnu.targets.arm.rtsv7M.Settings ========
 */



#endif /* gnu_targets_arm_rtsv7M__ */ 
