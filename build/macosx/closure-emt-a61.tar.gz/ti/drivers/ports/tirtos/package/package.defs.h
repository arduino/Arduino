/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_drivers_ports_tirtos__
#define ti_drivers_ports_tirtos__



#endif /* ti_drivers_ports_tirtos__ */ 
