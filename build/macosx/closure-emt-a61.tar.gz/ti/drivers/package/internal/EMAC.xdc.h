/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_drivers_EMAC__INTERNAL__
#define ti_drivers_EMAC__INTERNAL__

#ifndef ti_drivers_EMAC__internalaccess
#define ti_drivers_EMAC__internalaccess
#endif

#include <ti/drivers/EMAC.h>

#undef xdc_FILE__
#ifndef xdc_FILE
#define xdc_FILE__ NULL
#else
#define xdc_FILE__ xdc_FILE
#endif



#endif /* ti_drivers_EMAC__INTERNAL____ */
