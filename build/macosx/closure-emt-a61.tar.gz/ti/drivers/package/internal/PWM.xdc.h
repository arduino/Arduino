/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_drivers_PWM__INTERNAL__
#define ti_drivers_PWM__INTERNAL__

#ifndef ti_drivers_PWM__internalaccess
#define ti_drivers_PWM__internalaccess
#endif

#include <ti/drivers/PWM.h>

#undef xdc_FILE__
#ifndef xdc_FILE
#define xdc_FILE__ NULL
#else
#define xdc_FILE__ xdc_FILE
#endif



#endif /* ti_drivers_PWM__INTERNAL____ */
