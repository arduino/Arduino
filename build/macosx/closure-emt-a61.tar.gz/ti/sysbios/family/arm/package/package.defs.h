/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_family_arm__
#define ti_sysbios_family_arm__


/*
 * ======== module ti.sysbios.family.arm.HwiCommon ========
 */

typedef struct ti_sysbios_family_arm_HwiCommon_Module_State ti_sysbios_family_arm_HwiCommon_Module_State;

/*
 * ======== module ti.sysbios.family.arm.IntrinsicsSupport ========
 */

typedef struct ti_sysbios_family_arm_IntrinsicsSupport_Fxns__ ti_sysbios_family_arm_IntrinsicsSupport_Fxns__;
typedef const ti_sysbios_family_arm_IntrinsicsSupport_Fxns__* ti_sysbios_family_arm_IntrinsicsSupport_Module;

/*
 * ======== module ti.sysbios.family.arm.Mpu ========
 */

typedef struct ti_sysbios_family_arm_Mpu_RegionAttrs ti_sysbios_family_arm_Mpu_RegionAttrs;
typedef struct ti_sysbios_family_arm_Mpu_RegionEntry ti_sysbios_family_arm_Mpu_RegionEntry;
typedef struct ti_sysbios_family_arm_Mpu_Module_State ti_sysbios_family_arm_Mpu_Module_State;

/*
 * ======== module ti.sysbios.family.arm.TaskSupport ========
 */

typedef struct ti_sysbios_family_arm_TaskSupport_Fxns__ ti_sysbios_family_arm_TaskSupport_Fxns__;
typedef const ti_sysbios_family_arm_TaskSupport_Fxns__* ti_sysbios_family_arm_TaskSupport_Module;


#endif /* ti_sysbios_family_arm__ */ 
