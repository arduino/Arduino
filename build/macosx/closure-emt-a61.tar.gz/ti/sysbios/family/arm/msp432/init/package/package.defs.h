/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_family_arm_msp432_init__
#define ti_sysbios_family_arm_msp432_init__


/*
 * ======== module ti.sysbios.family.arm.msp432.init.Boot ========
 */



#endif /* ti_sysbios_family_arm_msp432_init__ */ 
