/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_sysbios_family_arm_msp432__
#define ti_sysbios_family_arm_msp432__


/*
 * ======== module ti.sysbios.family.arm.msp432.Timer ========
 */

typedef struct ti_sysbios_family_arm_msp432_Timer_Control ti_sysbios_family_arm_msp432_Timer_Control;
typedef struct ti_sysbios_family_arm_msp432_Timer_TimerDevice ti_sysbios_family_arm_msp432_Timer_TimerDevice;
typedef struct ti_sysbios_family_arm_msp432_Timer_Module_State ti_sysbios_family_arm_msp432_Timer_Module_State;
typedef struct ti_sysbios_family_arm_msp432_Timer_Fxns__ ti_sysbios_family_arm_msp432_Timer_Fxns__;
typedef const ti_sysbios_family_arm_msp432_Timer_Fxns__* ti_sysbios_family_arm_msp432_Timer_Module;
typedef struct ti_sysbios_family_arm_msp432_Timer_Params ti_sysbios_family_arm_msp432_Timer_Params;
typedef struct ti_sysbios_family_arm_msp432_Timer_Object ti_sysbios_family_arm_msp432_Timer_Object;
typedef struct ti_sysbios_family_arm_msp432_Timer_Struct ti_sysbios_family_arm_msp432_Timer_Struct;
typedef ti_sysbios_family_arm_msp432_Timer_Object* ti_sysbios_family_arm_msp432_Timer_Handle;
typedef struct ti_sysbios_family_arm_msp432_Timer_Object__ ti_sysbios_family_arm_msp432_Timer_Instance_State;
typedef ti_sysbios_family_arm_msp432_Timer_Object* ti_sysbios_family_arm_msp432_Timer_Instance;

/*
 * ======== module ti.sysbios.family.arm.msp432.TimestampProvider ========
 */

typedef struct ti_sysbios_family_arm_msp432_TimestampProvider_Module_State ti_sysbios_family_arm_msp432_TimestampProvider_Module_State;
typedef struct ti_sysbios_family_arm_msp432_TimestampProvider_Fxns__ ti_sysbios_family_arm_msp432_TimestampProvider_Fxns__;
typedef const ti_sysbios_family_arm_msp432_TimestampProvider_Fxns__* ti_sysbios_family_arm_msp432_TimestampProvider_Module;

/*
 * ======== module ti.sysbios.family.arm.msp432.ClockFreqs ========
 */

typedef struct ti_sysbios_family_arm_msp432_ClockFreqs_Module_State ti_sysbios_family_arm_msp432_ClockFreqs_Module_State;


#endif /* ti_sysbios_family_arm_msp432__ */ 
