/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_runtime_wiring_cc3200_variants_CC3200_LAUNCHXL__
#define ti_runtime_wiring_cc3200_variants_CC3200_LAUNCHXL__



#endif /* ti_runtime_wiring_cc3200_variants_CC3200_LAUNCHXL__ */ 
