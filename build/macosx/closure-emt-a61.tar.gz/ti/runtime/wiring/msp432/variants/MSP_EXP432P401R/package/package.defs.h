/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_runtime_wiring_msp432_variants_MSP_EXP432P401R__
#define ti_runtime_wiring_msp432_variants_MSP_EXP432P401R__



#endif /* ti_runtime_wiring_msp432_variants_MSP_EXP432P401R__ */ 
