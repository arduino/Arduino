/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A71
 */

#ifndef ti_runtime_wiring_cc26xx_variants_CC2650STK_BLE__
#define ti_runtime_wiring_cc26xx_variants_CC2650STK_BLE__



#endif /* ti_runtime_wiring_cc26xx_variants_CC2650STK_BLE__ */ 
